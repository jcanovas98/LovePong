function love.conf(t)
  t.window.width = 800  
  t.window.height = 600
  t.console = true
  t.title = "LovePong 2018"
end

